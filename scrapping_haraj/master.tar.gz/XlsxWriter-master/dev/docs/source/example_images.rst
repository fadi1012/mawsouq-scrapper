.. _ex_insert_image:

Example: Inserting images into a worksheet
==========================================

This program is an example of inserting images into a worksheet. See the
:func:`insert_image` method for more details.

.. image:: _images/images.png

.. literalinclude:: ../../../examples/images.py


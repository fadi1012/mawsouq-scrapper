.. _ex_comments1:

Example: Adding Cell Comments to Worksheets (Simple)
====================================================

A simple example of adding cell comments to a worksheet. For more details see
:ref:`cell_comments`.

.. image:: _images/comments1.png

.. literalinclude:: ../../../examples/comments1.py

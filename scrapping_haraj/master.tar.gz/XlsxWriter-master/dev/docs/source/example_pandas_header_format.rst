.. _ex_pandas_header_format:

Example: Pandas Excel output with user defined header format
============================================================

An example of converting a Pandas dataframe to an Excel file with a user
defined header format using Pandas and XlsxWriter.

.. image:: _images/pandas_header_format.png

.. literalinclude:: ../../../examples/pandas_header_format.py

.. _ex_autofilter:

Example: Applying Autofilters
=============================

This program is an example of using autofilters in a worksheet. See
:ref:`working_with_autofilters` for more details.

.. image:: _images/autofilter3.png

.. literalinclude:: ../../../examples/autofilter.py

